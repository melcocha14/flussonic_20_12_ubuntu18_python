"""v19.08

Revision ID: v19.08
Revises: ecefe294d46f
Create Date: 2019-10-31 18:48:11.050542

"""

# revision identifiers, used by Alembic.
revision = 'v19.08'
down_revision = 'ecefe294d46f'

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
