"""add_user_permissions

Revision ID: e0ffbf0a8b28
Revises: a9aec64ab203
Create Date: 2019-05-07 07:09:55.709573

"""

# revision identifiers, used by Alembic.
revision = 'e0ffbf0a8b28'
down_revision = 'a9aec64ab203'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

def upgrade():
  JSONBType = sa.dialects.postgresql.JSONB
  op.add_column('users', sa.Column('permissions', JSONBType(), nullable=True))


def downgrade():
  op.drop_column('users', 'permissions')

    