"""v19.10

Revision ID: v19.10
Revises: b8129f2524cd
Create Date: 2019-10-31 18:39:33.709166

"""

# revision identifiers, used by Alembic.
revision = 'v19.10'
down_revision = 'b8129f2524cd'

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
