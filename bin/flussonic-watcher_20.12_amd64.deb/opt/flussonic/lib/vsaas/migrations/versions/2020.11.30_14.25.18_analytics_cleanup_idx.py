"""analytics cleanup idx

Revision ID: ccba469705ac
Revises: 4d7f641b9095
Create Date: 2020-11-30 14:25:18.660872

"""

# revision identifiers, used by Alembic.
revision = 'ccba469705ac'
down_revision = '4d7f641b9095'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    op.execute('create index ix_license_plates_id_has_preview on license_plates(id) where preview is not null')
    op.execute('create index ix_activity_faces_id_has_preview on activity_faces(id) where preview is not null')
    op.execute('create index ix_license_plates_start_at on license_plates (start_at desc)')
    pass


def downgrade():
    op.execute('DROP INDEX IF EXISTS ix_activity_faces_id_has_preview')
    op.execute('DROP INDEX IF EXISTS ix_license_plates_id_has_preview')
    op.execute('DROP INDEX IF EXISTS ix_license_plates_start_at')
    pass
