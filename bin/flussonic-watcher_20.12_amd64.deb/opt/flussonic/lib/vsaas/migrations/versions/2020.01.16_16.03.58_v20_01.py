"""v20.01

Revision ID: v20.01
Revises: 64b722d22ee8
Create Date: 2020-01-16 16:03:58.418437

"""

# revision identifiers, used by Alembic.
revision = 'v20.01'
down_revision = '64b722d22ee8'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
