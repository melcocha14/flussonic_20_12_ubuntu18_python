"""v19.12

Revision ID: v19.12
Revises: f07d9801dc97
Create Date: 2019-12-03 13:41:23.944755

"""

# revision identifiers, used by Alembic.
revision = 'v19.12'
down_revision = 'f07d9801dc97'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
