"""v20.11

Revision ID: v20.11
Revises: d7cc42042c08
Create Date: 2020-11-02 13:29:37.593076

"""

# revision identifiers, used by Alembic.
revision = 'v20.11'
down_revision = 'd7cc42042c08'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
