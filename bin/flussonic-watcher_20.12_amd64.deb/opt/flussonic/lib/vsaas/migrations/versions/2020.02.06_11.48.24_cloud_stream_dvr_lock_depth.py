"""cloud_stream:dvr_lock_depth

Revision ID: b58574bc7307
Revises: a59e7d3f28fd
Create Date: 2019-10-25 11:48:24.749251

"""

# revision identifiers, used by Alembic.
from alembic import op
import sqlalchemy as sa

revision = 'b58574bc7307'
down_revision = 'a59e7d3f28fd'


def upgrade():
  op.add_column(
    'cloud_streams',
    sa.Column('dvr_lock_days', sa.Integer(), nullable=True))

  op.add_column(
    'presets',
    sa.Column('dvr_lock_days', sa.Integer(), nullable=True))

  op.add_column(
    'stream_statuses',
    sa.Column('dvr_bytes', sa.BigInteger(), nullable=True))


def downgrade():
  op.drop_column('cloud_streams', 'dvr_lock_days')
  op.drop_column('presets', 'dvr_lock_days')
  op.drop_column('stream_statuses', 'dvr_bytes')
