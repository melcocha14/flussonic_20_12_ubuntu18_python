"""push timeout

Revision ID: 92af0e136265
Revises: v19.09
Create Date: 2019-08-30 23:53:13.374808

"""

# revision identifiers, used by Alembic.
revision = '92af0e136265'
down_revision = 'v19.09'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


def upgrade():
    op.add_column('event_subscriptions', sa.Column('last_event_at', sa.Integer(), nullable=False, server_default='0'))
    op.add_column('event_subscriptions', sa.Column('send_timeout', sa.Integer(), nullable=False, server_default='30'))


def downgrade():
    op.drop_column('event_subscriptions', 'send_timeout')
    op.drop_column('event_subscriptions', 'last_event_at')
