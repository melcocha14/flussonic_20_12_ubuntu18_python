"""v20.06

Revision ID: v20.06
Revises: v20.05
Create Date: 2020-06-02 17:43:31.615999

"""

# revision identifiers, used by Alembic.
revision = 'v20.06'
down_revision = 'v20.05'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
