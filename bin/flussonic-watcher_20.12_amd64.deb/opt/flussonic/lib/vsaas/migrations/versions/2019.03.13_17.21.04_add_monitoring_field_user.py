"""add_monitoring_field_user

Revision ID: 6751348afe80
Revises: ee545b0518c2
Create Date: 2019-03-13 17:21:04.224958

"""

# revision identifiers, used by Alembic.
revision = '6751348afe80'
down_revision = 'ee545b0518c2'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

def upgrade():
    op.add_column('users', sa.Column('monitoring', sa.Boolean(), nullable=False, server_default=sa.sql.false()))


def downgrade():
    op.drop_column('users', 'monitoring')


    