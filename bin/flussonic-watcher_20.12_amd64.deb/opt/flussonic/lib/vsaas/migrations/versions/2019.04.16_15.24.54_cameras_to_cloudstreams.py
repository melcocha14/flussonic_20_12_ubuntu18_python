"""cameras_to_cloudstreams

Revision ID: 590b24d4b14b
Revises: 9a3cbe077362
Create Date: 2019-04-16 15:24:54.224894

"""

# revision identifiers, used by Alembic.
revision = '590b24d4b14b'
down_revision = '9a3cbe077362'

from alembic import op
import sqlalchemy as sa


def upgrade():
  pass


def downgrade():
  pass