"""v20.05

Revision ID: v20.05
Revises: 772e49544a48
Create Date: 2020-05-07 10:09:28.339737

"""

# revision identifiers, used by Alembic.
revision = 'v20.05'
down_revision = '772e49544a48'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
